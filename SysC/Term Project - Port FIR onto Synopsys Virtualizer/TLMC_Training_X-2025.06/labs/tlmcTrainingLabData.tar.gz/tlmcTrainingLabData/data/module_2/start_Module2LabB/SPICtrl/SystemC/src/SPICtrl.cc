/***************************************************************************
 * Copyright 1996-2024 Synopsys, Inc.
 *
 * This Synopsys software and all associated documentation are proprietary
 * to Synopsys, Inc. and may only be used pursuant to the terms and
 * conditions of a written license agreement with Synopsys, Inc.
 * All other use, reproduction, modification, or distribution of the
 * Synopsys software or the associated documentation is strictly prohibited.
 ***************************************************************************/
 

/***************************************************************************
 * Generated snippet, used for detecting user edits.
 * CHECKSUM:0000000000000000000000000000000000000000
 ***************************************************************************/
 
#include "SPICtrl.h"


SPICtrl::SPICtrl(sc_core::sc_module_name name) : SPICtrlBase(name)  {
  
}

void SPICtrl::handle_Serial_IO_protocol_engine_start_received_transfer_64bit_V3(unsigned long long data, unsigned bit_length, bool continuous_select) {
  // FIXME: Default implementation. Implement this.
}

void SPICtrl::handle_Serial_IO_protocol_engine_end_received_transfer() {
  // FIXME: Default implementation. Implement this.
}

void SPICtrl::handle_rst_in_protocol_engine_reset_enter() {
  // FIXME: Default implementation. Implement this.
}

void SPICtrl::handle_spi_clk_protocol_engine_period_updated(sc_core::sc_time period) {
  this->Serial_IO_protocol_engine.bit_time = period;
}

