/***************************************************************************
 * Copyright 1996-2024 Synopsys, Inc.
 *
 * This Synopsys software and all associated documentation are proprietary
 * to Synopsys, Inc. and may only be used pursuant to the terms and
 * conditions of a written license agreement with Synopsys, Inc.
 * All other use, reproduction, modification, or distribution of the
 * Synopsys software or the associated documentation is strictly prohibited.
 ***************************************************************************/
 

/***************************************************************************
 * Generated snippet, used for detecting user edits.
 * CHECKSUM:1d50d0c7329f9b06fd9d1d3158d8576afb151034
 ***************************************************************************/
 
#include "timer.h"


timer::timer(sc_core::sc_module_name name) : timerBase(name)  {
  
}

void timer::handle_p_reset_protocol_engine_reset_enter() {
  reset_model();
}

bool timer::handle_read_ITADR(unsigned int& value, const unsigned int& byteEnables) {
	  if ( byteEnables != 0xFFFFFFFF ) {
	SCML2_INFO(FUNCTIONAL_LOG) << "only 32bit access allowed - " <<
	"disabling access (byteEnables= " << byteEnables << ")" << endl;
	} else {
	int counter = timer_object.counter-1;
	SCML2_MODEL_INTERNAL(LEVEL4) << " counter = " << counter << endl;
	if ( timer_object.is_active() ) {
	value = counter;
	} else {
	value = ITDR;
	}
	}
	  return true;
}

scml2::access_restriction_result timer::restrict_ITDR(unsigned int& data, unsigned int& bit_enables) {
	if ( bit_enables != 0xFFFFFFFF ) {
	SCML2_INFO(FUNCTIONAL_LOG) << "only 32bit access allowed - disabling access (bit_enables= "
	<< bit_enables << ")" << endl;
	bit_enables = 0x0;
	} else {
	bit_enables &= 0x0000FFFF;
	}
    return scml2::RESTRICT_NO_ERROR;
}
#ifdef TLMC_ORPHANDED_handle_timer_object_alarm
void timer::handle_timer_object_alarm() {
  ITCSR.ITIF = 1;
}
#endif
void timer::handle_timer_object_alarm() {
  ITCSR.ITIF = 1;
}

