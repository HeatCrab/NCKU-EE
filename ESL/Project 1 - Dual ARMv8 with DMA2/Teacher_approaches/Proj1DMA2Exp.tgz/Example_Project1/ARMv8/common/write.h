#include <stdint.h>

#define UART_BASE 0x90000  // Example (QEMU PL011 UART)

int _write(int fd, char *buf, int count) {
    volatile uint32_t *uart = (uint32_t *)UART_BASE;

    for (int i = 0; i < count; i++) {
        *uart = buf[i];  // send char
    }

    return count;
}
