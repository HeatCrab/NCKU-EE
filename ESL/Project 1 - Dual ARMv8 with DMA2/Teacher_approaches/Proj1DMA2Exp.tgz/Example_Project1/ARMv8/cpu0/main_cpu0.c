#include "../common/DMA2_regs.h"
#include "../common/write.h"

#define RAM2_DATA_START 0x200400
#define FLAG_ADDR       0x200800

void dma2_int1_handler() {
    // 1. Acknowledge/Clear the interrupt in DMA2 
    // Usually done by writing to a status bit or the START0 register
    *(volatile int*)(DMA2_BASE + 0xC) = 0; 

    // 2. Perform synchronization action: Set flag to 0x1 
    // to signal ARMv8-1 that it can start its move (Step D)
    *(volatile int*)FLAG_ADDR = 0x1;

    //printf("ISR ARMv8-0: DMA Transfer Complete, Flag set to 1\n");
}

void main() {
    // A. Initialize 1KB data in RAM2
    char *src = (char*)RAM2_DATA_START;
    for(int i=0; i<1024; i++) src[i] = "0123456789ABCDEF"[i % 16];

    for(int repeat=0; repeat<3; repeat++) {
        // C. Monitor flag at 0x200800. Wait for 0x0
        while(*(volatile int*)FLAG_ADDR != 0x0);

        // Program DMA2 Set 1 to move 1KB from RAM2 (0x200400)
        // to RAM3 (0x300000)
        *(volatile int*)(DMA2_CH0_SRC)  = RAM2_DATA_START; // SOURCE0
        *(volatile int*)(DMA2_CH0_DST)  = RAM3_BASE;       // TARGET0
        *(volatile int*)(DMA2_CH0_SIZE) = 1024;            // SIZE0
        *(volatile int*)(DMA2_CH0_CTRL) = 1;               // START0

        // Wait for DMA completion (via Interrupt or polling START0)
        while(*(volatile int*)(DMA2_CH0_CTRL) != 0);

        // D. Write 0x1 to FLAG_ADDR
        *(volatile int*)FLAG_ADDR = 0x1;
        char msg[] = "ARMv8-0: Transfer complete once\n";
        _write(1, msg, sizeof(msg));
    }
}
