#include "../common/DMA2_regs.h"
#include "../common/write.h"

#define RAM3_DATA_START 0x300400
#define FLAG_ADDR       0x200800

void dma2_int2_handler() {
    // 1. Acknowledge/Clear the interrupt in DMA2
    *(volatile int*)(DMA2_BASE + 0x1C) = 0; 

    // 2. Perform synchronization action: Set flag to 0x0 
    // to signal ARMv8-0 that it can start its move (Step F)
    *(volatile int*)FLAG_ADDR = 0x0;

    //printf("ISR ARMv8-1: DMA Transfer Complete, Flag set to 0\n");
}

void main() {
    // B. Initialize 1KB data in RAM3 [cite: 49]
    char *src = (char*)RAM3_DATA_START;
    for(int i=0; i<1024; i++) src[i] = "FEDCBA9876543210"[i % 16];

    for(int repeat=0; repeat<3; repeat++) {
        // E. Monitor flag at 0x200800. Wait for 0x1
        while(*(volatile int*)FLAG_ADDR != 0x1);

        // Program DMA2 Set 2 to move 1KB from RAM3 (0x300400)
        // to RAM2 (0x200000)
        *(volatile int*)(DMA2_CH1_SRC)  = RAM3_DATA_START; // SOURCE1
        *(volatile int*)(DMA2_CH1_DST)  = RAM2_BASE;       // TARGET1
        *(volatile int*)(DMA2_CH1_SIZE) = 1024;            // SIZE1
        *(volatile int*)(DMA2_CH1_CTRL) = 1;               // START1

        // Wait for DMA completion
        while(*(volatile int*)(DMA2_CH1_CTRL) != 0);

        // F. Write 0x0 to FLAG_ADDR
        *(volatile int*)FLAG_ADDR = 0x0;
        char msg[] = "ARMv8-1: Transfer complete once\n";
        _write(1, msg, sizeof(msg));
    }
}
