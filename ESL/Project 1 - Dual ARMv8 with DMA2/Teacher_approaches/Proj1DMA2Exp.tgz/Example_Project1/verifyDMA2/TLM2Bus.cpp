#include "TLM2Bus.h"

void TLM2Bus::b_transport(int id, tlm::tlm_generic_payload& trans,
                       sc_time& delay) {
    // Default: Forward to the first connected initiator (id 0)
    sc_dt::uint64 addr = trans.get_address();
    if (zeroOne) {
        if (addr >= 0x00000 && addr < 0xFFFFF)
            Msocket[0]->b_transport(trans, delay);
        else if (addr >= 0x100000 && addr < 0x500000)
            Msocket[1]->b_transport(trans, delay);
        else {
            std::cout << "Bus0 address out of range: 0x"
                      << std::hex << addr << std::endl;
            sc_stop();
        }
    } else {
        if (addr >= 0x100000 && addr < 0x10001F)
            Msocket[0]->b_transport(trans, delay);
        else if (addr >= 0x200000 && addr < 0x2FFFFF)
            Msocket[1]->b_transport(trans, delay);
        else if (addr >= 0x300000 && addr < 0x5FFFFF)
            Msocket[2]->b_transport(trans, delay);
        else {
            std::cout << "Bus1 address out of range: 0x"
                      << std::hex << addr << std::endl;
            sc_stop();
        }
    }
}
