#include <systemc.h>
#include <tlm.h>
#include "tlm_utils/multi_passthrough_initiator_socket.h"
#include "tlm_utils/multi_passthrough_target_socket.h"

// Define the Bus as a standard SC_MODULE
class TLM2Bus: public sc_module {
public:
    // Multi-sockets allow multiple connections to a single bus instance
    tlm_utils::multi_passthrough_initiator_socket<TLM2Bus> Msocket;
    tlm_utils::multi_passthrough_target_socket<TLM2Bus>    Ssocket;

    TLM2Bus(sc_module_name name, bool zeroOne_) : zeroOne(zeroOne_),
                                  Msocket("Msocket"), Ssocket("Ssocket") {
        // Register the callback for forward transactions
        Ssocket.register_b_transport(this, &TLM2Bus::b_transport);
    }

    // This function will be overridden or customized in the Top module 
    // to define specific routing for Bus1, Bus2, and Bus3.
    virtual void b_transport(int, tlm::tlm_generic_payload&, sc_time&);

    bool zeroOne = true;
};

