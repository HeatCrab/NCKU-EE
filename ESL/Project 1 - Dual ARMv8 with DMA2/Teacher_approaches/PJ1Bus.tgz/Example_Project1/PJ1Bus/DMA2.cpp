#include "DMA2.h"

void DMA2::b_transport(tlm::tlm_generic_payload& trans, sc_time& r_delay) {
    wait(r_delay);

    // Assumes all control registers are accessed as full 32-bit words
    tlm::tlm_command cmd_r = trans.get_command();
    unsigned char* r_data = trans.get_data_ptr();
    unsigned int r_len = trans.get_data_length();
    sc_dt::uint64 addr = trans.get_address();

    // Set OK status first, and change if anything goes otherwise
    trans.set_response_status(tlm::TLM_OK_RESPONSE);

    // Reading and writing control registers based on address
    addr -= BASE;
    if (cmd_r == tlm::TLM_WRITE_COMMAND) {
        std::cout << "DMA received WRITE at " << std::hex << "0x" << addr+BASE
                  << " length " << std::dec << r_len <<  ": ";
        switch (addr) {
            case 0x0:               // SOURCE0 register
                if (!block0) {
                    memcpy((unsigned char *)&SOURCE0, r_data, r_len);
                    std::cout << std::hex << "0x" << SOURCE0 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0x4:               // TARGET0 register
                if (!block0) {
                    memcpy((unsigned char *)&TARGET0, r_data, r_len);
                    std::cout << std::hex << "0x" << TARGET0 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0x8:              // SIZE0 register
                if (!block0) {
                    memcpy((unsigned char *)&SIZE0, r_data, r_len);
                    std::cout << std::hex << "0x" << SIZE0 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0xC:             // START0/CLEAR0 register
                memcpy((unsigned char *)&START0, r_data, r_len);
                std::cout << std::hex << "0x" << START0 << std::endl;
                if (START0 == 0x1)
                    block0 = true;  // Block from control register write
                else
                    block0 = false;
                break;
            case 0x10:            // SOURCE1 register
                if (!block1) {
                    memcpy((unsigned char *)&SOURCE1, r_data, r_len);
                    std::cout << std::hex << "0x" << SOURCE1 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0x14:            // TARGET1 register
                if (!block1) {
                    memcpy((unsigned char *)&TARGET1, r_data, r_len);
                    std::cout << std::hex << "0x" << TARGET1 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0x18:            // SIZE1 register
                if (!block1) {
                    memcpy((unsigned char *)&SIZE1, r_data, r_len);
                    std::cout << std::hex << "0x" << SIZE1 << std::endl;
                } else {
                    trans.set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
                    std::cout << "blocked" << std::endl;
                }
                break;
            case 0x1C:           // START1/CLEAR1 register
                memcpy((unsigned char *)&START1, r_data, r_len);
                std::cout << std::hex << "0x" << START1 << std::endl;
                if (START1 == 0x1)
                    block1 = true;  // Block from control register write
                else
                    block1 = false;
                break;
            default:
                trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
                std::cout << std::hex << "wrong address" << std::endl;
        }
    } else if (cmd_r == tlm::TLM_READ_COMMAND) {
        switch (addr) {
            case 0x0:
                memcpy(r_data, (unsigned char *)&SOURCE0, r_len);
                break;
            case 0x4:
                memcpy(r_data, (unsigned char *)&TARGET0, r_len);
                break;
            case 0x8:
                memcpy(r_data, (unsigned char *)&SIZE0, r_len);
                break;
            case 0xC:
                memcpy(r_data, (unsigned char *)&START0, r_len);
                break;
            case 0x10:
                memcpy(r_data, (unsigned char *)&SOURCE1, r_len);
                break;
            case 0x14:
                memcpy(r_data, (unsigned char *)&TARGET1, r_len);
                break;
            case 0x18:
                memcpy(r_data, (unsigned char *)&SIZE1, r_len);
                break;
            case 0x1C:
                memcpy(r_data, (unsigned char *)&START1, r_len);
                break;
            default:
                break;
        }
        std::cout << "DMA received READ at " << std::hex << "0x" << addr+BASE
                  << "length " << std::dec << r_len <<  ": "
                  << std::hex << "0x" << (sc_uint<32>)*r_data << std::endl;
    } else {               // TLM_IGNORE_COMMAND
        std::cout << "DMA receives TLM_IGNORE_COMMAND" << std::endl;
    }

    return;
}

void DMA2::dma_process0() {
    // Reset behavior
    SOURCE0 = 0;
    TARGET0 = 0;
    SIZE0 = 0;
    START0 = 0;
    block0 = false;
    intr0 = false;
    INT0.write(false);

    // DMA operational loop
    while (true) {
        wait();

        unsigned int rwData0 = 0;
        // Start DMA transfer
        if (START0) {
            if (SIZE0 > 0) {
                // TLM transaction common parameters
                trans0.set_data_ptr(trf_data0);
                if (SIZE0 >= 4)
                    trans0.set_data_length(4);
                else
                    trans0.set_data_length(SIZE0);

                //std::cout << "DMA SOURCE0 = " << std::hex << SOURCE0
                //        << " TARGET0 = " << std::hex << TARGET0 << std::endl;
                // TLM read transaction
                // trans0.set_command(tlm::TLM_READ_COMMAND);
                trans0.set_read();  // set TLM_READ_COMMAND
                trans0.set_address(SOURCE0);
                Msocket0->b_transport(trans0, delay);
                memcpy(&rwData0, trf_data0, 4);
                std::cout << "DMA0 read 0x" << std::hex << SOURCE0 << ":0x"
                          <<  rwData0 << std::endl;

                // Write to target
                // trans0.set_command(tlm::TLM_WRITE_COMMAND);
                trans0.set_write();  // set TLM_WRITE_COMMAND
                trans0.set_address(TARGET0);
                Msocket0->b_transport(trans0, delay);
                std::cout << "DMA0 write 0x" << std::hex << TARGET0 << ":0x"
                          <<  rwData0 << std::endl;

                if (SIZE0 > 4) {
                    SOURCE0 += 4;
                    TARGET0 += 4;
                    SIZE0 -= 4;
                } else
                    SIZE0 = 0;
                continue;
            }

            // Signal transfer is complete
            if (!intr0) {
                INT0.write(true);
                intr0 = true;        // Interrupt pulled
                std::cout << "DMA INT0 sent" << std::endl;
            }
        } else {
            block0 = false;  // Resume control register write
            if (intr0) {
                INT0.write(0);
                intr0 = false;   // Interrupt cleared
                std::cout << "DMA clears INT0" << std::endl;
            }
        }
    }
}


void DMA2::dma_process1() {
    // Reset behavior
    SOURCE1 = 0;
    TARGET1 = 0;
    SIZE1 = 0;
    START1 = 0;
    block1 = false;
    intr1 = false;
    INT1.write(false);

    // DMA operational loop
    while (true) {
        wait();

        unsigned int rwData1 = 0;
        // Start DMA transfer
        if (START1) {
            if (SIZE1 > 0) {
                // TLM transaction common parameters
                trans1.set_data_ptr(trf_data1);
                if (SIZE1 >= 4)
                    trans1.set_data_length(4);
                else
                    trans1.set_data_length(SIZE1);

                //std::cout << "DMA TARGET1 = " << std::hex << SOURCE
                //        << " TARGET1 = " << std::hex << TARGET0 << std::endl;
                // TLM read transaction
                // trans1.set_command(tlm::TLM_READ_COMMAND);
                trans1.set_read();  // set TLM_READ_COMMAND
                trans1.set_address(SOURCE1);
                Msocket1->b_transport(trans1, delay);
                memcpy(&rwData1, trf_data1, 4);
                std::cout << "DMA1 read 0x" << std::hex << SOURCE1 << ":0x"
                          <<  rwData1 << std::endl;

                // Write to target
                // trans1.set_command(tlm::TLM_WRITE_COMMAND);
                trans1.set_write();  // set TLM_WRITE_COMMAND
                trans1.set_address(TARGET1);
                Msocket1->b_transport(trans1, delay);
                std::cout << "DMA1 write 0x" << std::hex << TARGET1 << ":0x"
                          <<  rwData1 << std::endl;

                if (SIZE1 > 4) {
                    SOURCE1 += 4;
                    TARGET1 += 4;
                    SIZE1 -= 4;
                } else
                    SIZE1 = 0;
                continue;
            }

            // Signal transfer is complete
            if (!intr1) {
                INT1.write(true);
                intr1 = true;        // Interrupt pulled
                std::cout << "DMA INT1 sent" << std::endl;
            }
        } else {
            block1 = false;  // Resume control register write
            if (intr1) {
                INT1.write(0);
                intr1 = false;   // Interrupt cleared
                std::cout << "DMA clears INT1" << std::endl;
            }
        }
    }
}

